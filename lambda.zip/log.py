def log(message):
    print(f"Adicionando log via função", message)
